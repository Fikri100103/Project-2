<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Faskes extends CI_Controller {

    public function index() {
        $this->load->model('faskes_model', 'faskes');
        $list_faskes = $this->faskes->getAll();
        $data['list_faskes'] = $list_faskes;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('faskes/index', $data);
        $this->load->view('layout/footer');
    }

    public function create() {
        $data['judul'] = 'From Kelola Fasilitas Kesehatan';
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('faskes/create', $data);
        $this->load->view('layout/footer');
    }

    public function save() {
        $this->load->model('faskes_model', 'faskes');

        $_id = $this->input->post('id');
        $_nama = $this->input->post('nama');
        $_alamat = $this->input->post('alamat');
        $_latlong = $this->input->post('latlong');
        $_jenis_id = $this->input->post('jenis');
        $_deskripsi = $this->input->post('deskripsi');
        $_skor_rating = $this->input->post('skor');
        $_foto1 = $this->input->post('foto1');
        $_kecamatan_id = $this->input->post('kecamatan');
        $_website = $this->input->post('website');
        $_jumlah_dokter = $this->input->post('dokter');
        $_jumlah_pegawai = $this->input->post('pegawai');
        $_idedit = $this->input->post('idedit');

        $data_faskes[]=$_id;
        $data_faskes[]=$_nama;
        $data_faskes[]=$_alamat;
        $data_faskes[]=$_latlong;
        $data_faskes[]=$_jenis_id;
        $data_faskes[]=$_deskripsi;
        $data_faskes[]=$_skor_rating;
        $data_faskes[]=$_foto1;
        $data_faskes[]=$_kecamatan_id;
        $data_faskes[]=$_website;
        $data_faskes[]=$_jumlah_dokter;
        $data_faskes[]=$_jumlah_pegawai;

        if(isset($_idedit)) {
            $data_faskes[] = $_idedit;
            $this->faskes->update($data_faskes);
        } else {
            $this->faskes->save($data_faskes);
        }

        redirect(base_url().'index.php/faskes?id='.$_id, 'refresh');
    }

    public function edit() {
        $_id = $this->input->get('id');
        $this->load->model('faskes_model', 'faskes');
        $ubah = $this->faskes->findById($_id);

        $data['judul'] = 'From Update Fasilitas Kesehatan';
        $data['ubah'] = $ubah;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('faskes/update', $data);
        $this->load->view('layout/footer');
    }

    public function delete() {
        $_id = $this->input->get('id');
        $this->load->model('faskes_model', 'faskes');
        $this->faskes->delete($_id);
        redirect(base_url().'index.php/faskes', 'refresh');
    }

    public function upload() {
        $config['upload_path'] = './uploads/foto1/';
        $config['allowed_types'] = 'jpg|png';
        $config['max_size'] = '500';
        $config['max_width'] = '1024';
        $config['max_height'] = '768';

        $_id = $this->input->post('id');
        $array = explode('.', $_FILES['foto1']['name']);
        $extension = end($array);

        $new_name = $_id.'.'.$extension;
        $config['file_name'] = $new_name;

        $this->load->library('upload', $config);
        if(!$this->upload->do_upload('foto1')) {
            $error = array('error' => $this->upload->display_errors());
            $this->load->view('upload_form', $error);
        } else{
            $this->load->model('faskes_model', 'faskes');
            $array_data[] = $new_name;
            $array_data[] = $_id;
            $this->faskes->update_foto($array_data);

            $data = array('upload_data' => $this->uplaod->data());
        }
        redirect(base_url().'index.php/faskes?id='.$_id. 'refresh');
    }
}