<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Komentar extends CI_Controller {

    public function index() {
        $this->load->model('komentar_model', 'komentar');
        $list_komentar = $this->komentar->getAll();
        $data['list_komentar'] = $list_komentar;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('komentar/index', $data);
        $this->load->view('layout/footer');
    }

    public function create() {
        $data['judul'] = 'From Kelola komentar';
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('komentar/create', $data);
        $this->load->view('layout/footer');
    }

    public function save() {
        $this->load->model('komentar_model', 'komentar');

        $_id = $this->input->post('id');
        $_tanggal = $this->input->post('tanggal');
        $_isi = $this->input->post('isi');
        $_users_id = $this->input->post('user');
        $_faskes_id = $this->input->post('faskes');
        $_nilai_rating_id = $this->input->post('rating');
        $_idedit = $this->input->post('idedit');

        $data_komentar[]=$_id;
        $data_komentar[]=$_tanggal;
        $data_komentar[]=$_isi;
        $data_komentar[]=$_users_id;
        $data_komentar[]=$_faskes_id;
        $data_komentar[]=$_nilai_rating_id;

        if(isset($_idedit)) {
            $data_komentar[] = $_idedit;
            $this->komentar->update($data_komentar);
        } else {
            $this->komentar->save($data_komentar);
        }

        redirect(base_url().'index.php/komentar?id='.$_id, 'refresh');
    }

    public function edit() {
        $_id = $this->input->get('id');
        $this->load->model('komentar_model', 'komentar');
        $ubah = $this->komentar->findById($_id);

        $data['judul'] = 'From Update Komentar';
        $data['ubah'] = $ubah;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('komentar/update', $data);
        $this->load->view('layout/footer');
    }

    public function delete() {
        $_id = $this->input->get('id');
        $this->load->model('komentar_model', 'komentar');
        $this->komentar->delete($_id);
        redirect(base_url().'index.php/komentar', 'refresh');
    }
}