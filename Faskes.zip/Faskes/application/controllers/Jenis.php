<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jenis extends CI_Controller {

    public function index() {
        $this->load->model('jenis_model', 'jenis');
        $list_jenis = $this->jenis->getAll();
        $data['list_jenis'] = $list_jenis;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('jenis/index', $data);
        $this->load->view('layout/footer');
    }

    public function create() {
        $data['judul'] = 'From Kelola Jenis Fasilitas Kesehatan';
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('jenis/create', $data);
        $this->load->view('layout/footer');
    }

    public function save() {
        $this->load->model('jenis_model', 'jenis');

        $_id = $this->input->post('id');
        $_nama = $this->input->post('nama');
        $_idedit = $this->input->post('idedit');

        $data_jenis[]=$_id;
        $data_jenis[]=$_nama;

        if(isset($_idedit)) {
            $data_jenis[] = $_idedit;
            $this->jenis->update($data_jenis);
        } else {
            $this->jenis->save($data_jenis);
        }

        redirect(base_url().'index.php/jenis?id='.$_id, 'refresh');
    }

    public function edit() {
        $_id = $this->input->get('id');
        $this->load->model('jenis_model', 'jenis');
        $ubah = $this->jenis->findById($_id);

        $data['judul'] = 'From Update Jenis Fasilitas Kesehatan';
        $data['ubah'] = $ubah;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('jenis/update', $data);
        $this->load->view('layout/footer');
    }

    public function delete() {
        $_id = $this->input->get('id');
        $this->load->model('jenis_model', 'jenis');
        $this->jenis->delete($_id);
        redirect(base_url().'index.php/jenis', 'refresh');
    }
}