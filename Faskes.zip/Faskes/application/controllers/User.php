<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    public function index() {
        $this->load->model('user_model', 'user');
        $list_user = $this->user->getAll();
        $data['list_user'] = $list_user;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('user/index', $data);
        $this->load->view('layout/footer');
    }

    public function create() {
        $data['judul'] = 'From Kelola user';
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('user/create', $data);
        $this->load->view('layout/footer');
    }

    public function save() {
        $this->load->model('user_model', 'user');

        $_id = $this->input->post('id');
        $_username = $this->input->post('username');
        $_password = $this->input->post('password');
        $_email = $this->input->post('email');
        $_created_at = $this->input->post('created');
        $_last_login = $this->input->post('login');
        $_status = $this->input->post('status');
        $_role = $this->input->post('role');
        $_idedit = $this->input->post('idedit');

        $data_user[]=$_id;
        $data_user[]=$_username;
        $data_user[]=$_password;
        $data_user[]=$_email;
        $data_user[]=$_created_at;
        $data_user[]=$_last_login;
        $data_user[]=$_status;
        $data_user[]=$_role;

        if(isset($_idedit)) {
            $data_user[] = $_idedit;
            $this->user->update($data_user);
        } else {
            $this->user->save($data_user);
        }

        redirect(base_url().'index.php/user?id='.$_id, 'refresh');
    }

    public function edit() {
        $_id = $this->input->get('id');
        $this->load->model('user_model', 'user');
        $ubah = $this->user->findById($_id);

        $data['judul'] = 'From Update User';
        $data['ubah'] = $ubah;
        $this->load->view('layout/header');
        $this->load->view('layout/sidebar');
        $this->load->view('user/update', $data);
        $this->load->view('layout/footer');
    }

    public function delete() {
        $_id = $this->input->get('id');
        $this->load->model('user_model', 'user');
        $this->user->delete($_id);
        redirect(base_url().'index.php/user', 'refresh');
    }
}