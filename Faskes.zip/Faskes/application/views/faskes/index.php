<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Kelola Data Fasilitas Kesehatan</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Faskes</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">

    <!-- Default box -->
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">Data Fasilitas Kesehatan</h3>

        <div class="card-tools">
          <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
            <i class="fas fa-minus"></i>
          </button>
          <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
            <i class="fas fa-times"></i>
          </button>
        </div>
      </div>
      <div class="card-body">
        <h1>Daftar Fasilitas Kesehatan</h1>
        <div class='table-responsive'>
          <table class="table table-striped">
            <thead>
              <tr>
                <th>No</th>
                <th>ID</th>
                <th>Nama</th>
                <th>Alamat</th>
                <th>LatLong</th>
                <th>Jenis</th>
                <th>Deskripsi</th>
                <th>Skor Rating</th>
                <th>Foto</th>
                <th>Kecamatan</th>
                <th>Website</th>
                <th>Jumlah Dokter</th>
                <th>Jumlah Pegawai</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php
                $nomor = 1;
                foreach($list_faskes as $row) {
              ?>
                <tr>
                  <td><?=$nomor?></td>
                  <td><?=$row->id?></td>
                  <td><?=$row->nama?></td>
                  <td><?=$row->alamat?></td>
                  <td><?=$row->latlong?></td>
                  <td><?=$row->jenis_id?></td>
                  <td><?=$row->deskripsi?></td>
                  <td><?=$row->skor_rating?></td>
                  <td>
                    <?php
                      $filegambar = base_url('/uploads/foto1/'.$row->foto1);
                      $array = get_headers($filegambar);
                      $string = $array[0];
                      
                      if(strpos($string,"200")){
                        echo '<img width ="70%" src"'.$filegambar.'" class="img-thumbnail" alt="foto1"/>';
                      } else{
                        echo '<img src ="'.base_url('/uploads/noimage.png').'" alt="noimage" width="200"/>';
                      }
                    ?>
                    <br/>Nama File : <?=$row->foto1?>
                    <?php echo form_open_multipart('faskes/upload'); ?>

                      <input type="hidden" name="id" value="<?=$row->id?>"/>
                      <input type="file" name="foto1" size="20"/><br/>
                      <input type="submit" class="btn btn-primary" value="upload"><br/><br/>
                      
                    <?php echo form_close(); ?>
                  </td>
                  <td><?=$row->kecamatan_id?></td>
                  <td><?=$row->website?></td>
                  <td><?=$row->jumlah_dokter?></td>
                  <td><?=$row->jumlah_pegawai?></td>
                  <td>
                    <a href="faskes/edit?id=<?=$row->id?>">Edit</a>
                    <a href="faskes/delete?id=<?=$row->id?>"
                    onclick="if(!confirm('Anda Yakin Hapus Fasilitas Kesehatan ID <?=$row->id?>?')) {return false}"
                    >Delete</a>
                  </td>
                </tr>
              <?php
                $nomor++;    
                }
              ?>
            </tbody>
          </table>
        </div>
        <a class="btn btn-primary" href="<?php echo base_url('index.php/faskes/create')?>" role="button">Create</a>
      </div>
      <!-- /.card-body -->
      <div class="card-footer">
        Footer
      </div>
      <!-- /.card-footer-->
    </div>
    <!-- /.card -->

  </section>
  <!-- /.content -->
</div>