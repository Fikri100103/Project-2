 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?=$judul?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item"><a href="#">Faskes</a></li>
              <li class="breadcrumb-item active">Update</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card">
        <div class="card-header">
          <h3 class="card-title"><?=$judul?></h3>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
              <i class="fas fa-minus"></i>
            </button>
          </div>
        </div>
        <div class="card-body">
            <?php
                $hidden = ['idedit'=>$ubah->id];
            ?>
            <?php
                $selected_1 = ($ubah->jenis_id=='1')?"selected":"";
                $selected_2 = ($ubah->jenis_id=='2')?"selected":"";
                $selected_3 = ($ubah->jenis_id=='3')?"selected":"";
                $selected_4 = ($ubah->jenis_id=='4')?"selected":"";
                $selected_5 = ($ubah->jenis_id=='5')?"selected":"";
                $selected_6 = ($ubah->kecamatan_id=='1')?"selected":"";
                $selected_7 = ($ubah->kecamatan_id=='2')?"selected":"";
            ?>
            <?php echo form_open('faskes/save', '', $hidden)?>
                <div class="form-group row">
                    <label for="id" class="col-4 col-form-label">ID</label> 
                    <div class="col-8">
                        <input id="id" name="id" value="<?=$ubah->id?>" type="text" class="form-control">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="nama" class="col-4 col-form-label">Nama</label> 
                    <div class="col-8">
                        <input id="nama" name="nama" value="<?=$ubah->nama?>" type="text" class="form-control">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="alamat" class="col-4 col-form-label">Alamat</label> 
                    <div class="col-8">
                        <textarea id="alamat" name="alamat" cols="40" rows="3" class="form-control"><?=$ubah->alamat?></textarea>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="latlong" class="col-4 col-form-label">LatLong</label> 
                    <div class="col-8">
                        <input id="latlong" name="latlong" value="<?=$ubah->latlong?>" type="text" class="form-control">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="jenis" class="col-4 col-form-label">Jenis</label> 
                    <div class="col-8">
                        <select id="jenis" name="jenis" class="custom-select">
                            <!-- <option value=""></option> -->
                            <option value="1" <?=$selected_1?>>Rumah Sakit</option>
                            <option value="2" <?=$selected_2?>>Klinik Gigi</option>
                            <option value="3" <?=$selected_3?>>Klinik Umum</option>
                            <option value="4" <?=$selected_4?>>Puskesmas</option>
                            <option value="5" <?=$selected_5?>>Apotik</option>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="deskripsi" class="col-4 col-form-label">Deskripsi</label> 
                    <div class="col-8">
                        <textarea id="deskripsi" name="deskripsi" cols="40" rows="3" class="form-control"><?=$ubah->deskripsi?></textarea>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="skor" class="col-4 col-form-label">Skor Rating</label> 
                    <div class="col-8">
                        <input id="skor" name="skor" value="<?=$ubah->skor_rating?>" type="text" class="form-control">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="kecamatan" class="col-4 col-form-label">Kecamatan</label> 
                    <div class="col-8">
                        <select id="kecamatan" name="kecamatan" class="custom-select">
                            <!-- <option value=""></option> -->
                            <option value="1" <?=$selected_6?>>Beji</option>
                            <option value="2" <?=$selected_7?>>Pancoran Mas</option>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="dokter" class="col-4 col-form-label">Website</label> 
                    <div class="col-8">
                        <input id="website" name="website" value="<?=$ubah->website?>" type="text" class="form-control">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="dokter" class="col-4 col-form-label">Jumlah Dokter</label> 
                    <div class="col-8">
                        <input id="dokter" name="dokter" value="<?=$ubah->jumlah_dokter?>" type="text" class="form-control">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="pegawai" class="col-4 col-form-label">Jumlah Pegawai</label> 
                    <div class="col-8">
                        <input id="pegawai" name="pegawai" value="<?=$ubah->jumlah_pegawai?>" type="text" class="form-control">
                    </div>
                </div> 
                <div class="form-group row">
                    <div class="offset-4 col-8">
                        <button name="submit" type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            <?php echo form_close()?>
        </div>
        <!-- /.card-body -->
        <div class="card-footer">
          Footer
        </div>
        <!-- /.card-footer-->
      </div>
      <!-- /.card -->

    </section>
    <!-- /.content -->
  </div>