<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Kelola Data Komentar</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Komentar</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">

    <!-- Default box -->
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">Data Komentar</h3>

        <div class="card-tools">
          <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
            <i class="fas fa-minus"></i>
          </button>
          <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
            <i class="fas fa-times"></i>
          </button>
        </div>
      </div>
      <div class="card-body">
        <h1>Daftar komentar</h1>
        <div class='table-responsive'>
          <table class="table table-striped">
            <thead>
              <tr>
                <th>No</th>
                <th>ID</th>
                <th>Tanggal</th>
                <th>Isi</th>
                <th>Users Id</th>
                <th>Faskes Id</th>
                <th>Nilai Rating Id</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php
                $nomor = 1;
                foreach($list_komentar as $row) {
              ?>
                <tr>
                  <td><?=$nomor?></td>
                  <td><?=$row->id?></td>
                  <td><?=$row->tanggal?></td>
                  <td><?=$row->isi?></td>
                  <td><?=$row->users_id?></td>
                  <td><?=$row->faskes_id?></td>
                  <td><?=$row->nilai_rating_id?></td>
                  <td>
                    <a href="komentar/edit?id=<?=$row->id?>">Edit</a>
                    <a href="komentar/delete?id=<?=$row->id?>"
                    onclick="if(!confirm('Anda Yakin Hapus Komentar ID <?=$row->id?>?')) {return false}"
                    >Delete</a>
                  </td>
                </tr>
              <?php
                $nomor++;    
                }
              ?>
            </tbody>
          </table>
        </div>
        <a class="btn btn-primary" href="<?php echo base_url('index.php/komentar/create')?>" role="button">Create</a>
      </div>
      <!-- /.card-body -->
      <div class="card-footer">
        Footer
      </div>
      <!-- /.card-footer-->
    </div>
    <!-- /.card -->

  </section>
  <!-- /.content -->
</div>