<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?=$judul?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item"><a href="#">Komentar</a></li>
              <li class="breadcrumb-item active">Update</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card">
        <div class="card-header">
          <h3 class="card-title"><?=$judul?></h3>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
              <i class="fas fa-minus"></i>
            </button>
          </div>
        </div>
        <div class="card-body">
            <?php
                $hidden = ['idedit'=>$ubah->id];
            ?>
            <?php
                $selected_1 = ($ubah->users_id=='1')?"selected":"";
                $selected_2 = ($ubah->users_id=='2')?"selected":"";
                $selected_3 = ($ubah->users_id=='3')?"selected":"";
                $selected_4 = ($ubah->users_id=='4')?"selected":"";
                $selected_5 = ($ubah->users_id=='5')?"selected":"";
                $selected_6 = ($ubah->faskes_id=='1')?"selected":"";
                $selected_7 = ($ubah->faskes_id=='2')?"selected":"";
                $selected_8 = ($ubah->faskes_id=='3')?"selected":"";
                $selected_9 = ($ubah->faskes_id=='4')?"selected":"";
                $selected_10 = ($ubah->faskes_id=='5')?"selected":"";
                $selected_11 = ($ubah->nilai_rating_id=='1')?"selected":"";
                $selected_12 = ($ubah->nilai_rating_id=='2')?"selected":"";
                $selected_13 = ($ubah->nilai_rating_id=='3')?"selected":"";
                $selected_14 = ($ubah->nilai_rating_id=='4')?"selected":"";
                $selected_15 = ($ubah->nilai_rating_id=='5')?"selected":"";
            ?>
            <?php echo form_open('komentar/save', '', $hidden)?>
                <div class="form-group row">
                    <label for="id" class="col-4 col-form-label">ID</label> 
                    <div class="col-8">
                        <input id="id" name="id" value="<?=$ubah->id?> type="text" class="form-control">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="tanggal" class="col-4 col-form-label">Tanggal</label> 
                    <div class="col-8">
                        <input id="tanggal" name="tanggal" value="<?=$ubah->tanggal?> type="text" class="form-control">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="isi" class="col-4 col-form-label">Isi</label> 
                    <div class="col-8">
                        <input id="isi" name="isi" value="<?=$ubah->isi?> type="text" class="form-control">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="user" class="col-4 col-form-label">ID User</label> 
                    <div class="col-8">
                        <select id="user" name="user" class="custom-select">
                            <!-- <option value=""></option> -->
                            <option value="1" <?=$selected_1?>>1</option>
                            <option value="2" <?=$selected_2?>>2</option>
                            <option value="3" <?=$selected_3?>>3</option>
                            <option value="4" <?=$selected_4?>>4</option>
                            <option value="5" <?=$selected_5?>>5</option>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="faskes" class="col-4 col-form-label">ID Faskes</label> 
                    <div class="col-8">
                        <select id="faskes" name="faskes" class="custom-select">
                            <!-- <option value=""></option> -->
                            <option value="1" <?=$selected_6?>>1</option>
                            <option value="2" <?=$selected_7?>>2</option>
                            <option value="3" <?=$selected_8?>>3</option>
                            <option value="4" <?=$selected_9?>>4</option>
                            <option value="5" <?=$selected_10?>>5</option>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="rating" class="col-4 col-form-label">Nilai Rating</label> 
                    <div class="col-8">
                        <select id="rating" name="rating" class="custom-select">
                            <!-- <option value=""></option> -->
                            <option value="1" <?=$selected_11?>>Jelek</option>
                            <option value="2" <?=$selected_12?>>Kurang Bagus</option>
                            <option value="3" <?=$selected_13?>>Biasa Aja</option>
                            <option value="4" <?=$selected_14?>>Bagus</option>
                            <option value="5" <?=$selected_15?>>Sangat Bagus</option>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="offset-4 col-8">
                        <button name="submit" type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            <?php echo form_close()?>
        </div>
        <!-- /.card-body -->
        <div class="card-footer">
          Footer
        </div>
        <!-- /.card-footer-->
      </div>
      <!-- /.card -->

    </section>
    <!-- /.content -->
  </div>